// Test 1-1 selenium.
require('./p2p');

// Test three-party mesh.
// apparently too much for travis :-(
// TODO: investigate sauce labs
//require('./three');
